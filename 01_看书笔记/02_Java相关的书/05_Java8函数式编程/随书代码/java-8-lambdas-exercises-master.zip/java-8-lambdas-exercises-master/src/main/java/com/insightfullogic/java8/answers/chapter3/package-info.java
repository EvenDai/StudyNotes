package com.insightfullogic.java8.answers.chapter3;

/**
 * Question 1:
 *  See the Question1 class
 *
 * Question 2:
 *  see the Question2 class
 *
 * Question 3:
 * This question is to test how much we know about evaluation. So as we understood, Streams are lazy and others are Eager.
 *  a. Eager
 *  b. Lazy
 *
 * Question 4:
 *  a. Yes - takes a function as an argument
 *  b. No
 *
 * Question 5:
 *  a. Side Effect Free
 *  b. Mutates count
 *
 * Question 6:
 *  StringExercises
 *
 * Question 7:
 *  StringExercises
 */
