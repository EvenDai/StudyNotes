package com.insightfullogic.java8.examples.chapter8.template_method;

public class ApplicationDenied extends Exception {
}
