package com.insightfullogic.java8.examples.chapter4;

public class ChildImpl extends ParentImpl implements Child {
}
