package com.insightfullogic.java8.exercises.chapter9;

/**
 * The API gets refactored to CallbackArtistAnalyzer and
 * the code to CompletableFutureArtistAnalyser.
 */