package com.insightfullogic.java8.answers.chapter5;

/**
 * Question 2:
 *  a. see LongestName
 *  b. See WordCount
 *  c. See GroupingBy
 *
 * Question 3:
 *  See Fibonacci
 *
 */
