package com.insightfullogic.java8.answers.chapter6;

/**
 * Question 1:
 *  see SerialToParallel
 *
 * Question 2:
 *  See BuggyReduce
 *
 * Question 3:
 *  See OptimisationExampleFixed
 *
 */
