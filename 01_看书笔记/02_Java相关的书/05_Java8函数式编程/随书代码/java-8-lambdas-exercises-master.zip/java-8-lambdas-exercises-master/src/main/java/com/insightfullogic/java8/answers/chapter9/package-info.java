package com.insightfullogic.java8.answers.chapter9;

/**
 * The API gets refactored to CallbackArtistAnalyzer and
 * the code to CompletableFutureArtistAnalyser.
 */