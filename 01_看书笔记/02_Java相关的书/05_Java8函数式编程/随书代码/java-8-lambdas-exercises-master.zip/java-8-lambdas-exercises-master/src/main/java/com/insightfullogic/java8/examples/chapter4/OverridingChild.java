package com.insightfullogic.java8.examples.chapter4;

// BEGIN body
public class OverridingChild extends OverridingParent implements Child {

}
// END body
