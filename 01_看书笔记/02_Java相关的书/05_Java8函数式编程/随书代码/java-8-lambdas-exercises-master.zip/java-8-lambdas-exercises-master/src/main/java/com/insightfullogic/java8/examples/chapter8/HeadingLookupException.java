package com.insightfullogic.java8.examples.chapter8;

import java.io.IOException;

public class HeadingLookupException extends RuntimeException {
    public HeadingLookupException(IOException e) {
    }
}
