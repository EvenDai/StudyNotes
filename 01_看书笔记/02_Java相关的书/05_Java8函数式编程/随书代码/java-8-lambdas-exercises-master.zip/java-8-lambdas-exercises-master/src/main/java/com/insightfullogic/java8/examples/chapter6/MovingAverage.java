package com.insightfullogic.java8.examples.chapter6;

public class MovingAverage {

    /*public static void sma() {
        IntStream.range(0, 1000)
                 .reduce();
    }*/
}
