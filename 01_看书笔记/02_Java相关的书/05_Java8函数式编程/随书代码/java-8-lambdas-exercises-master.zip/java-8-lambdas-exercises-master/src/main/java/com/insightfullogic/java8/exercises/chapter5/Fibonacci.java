package com.insightfullogic.java8.exercises.chapter5;

import com.insightfullogic.java8.exercises.Exercises;

import java.util.HashMap;
import java.util.Map;

public class Fibonacci {

    public Fibonacci() {
    }

    public long fibonacci(int x) {
        return Exercises.replaceThisWithSolution();
    }

}
