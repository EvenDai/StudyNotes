package com.insightfullogic.java8.examples.chapter8.command;

// BEGIN Action
public interface Action {

    public void perform();

}
// END Action
