package com.insightfullogic.java8.examples.chapter4;

// BEGIN body
public interface Jukebox {

    public default String rock() {
        return "... all over the world!";
    }

}
// END body
