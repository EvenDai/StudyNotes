package com.insightfullogic.java8.exercises;

public class Exercises {

    public static <T> T replaceThisWithSolution() {
        throw new ExerciseNotCompletedException();
    }

}
