package com.insightfullogic.java8.exercises.chapter3;

/**
 * Question 1:
 *  See the Question1 class
 *
 * Question 2:
 *  see the Question2 class
 *
 * Question 3:
 *  a. Eager
 *  b. Lazy
 *
 * Question 4:
 *  a. Yes - takes a function as an argument
 *  b. No
 *
 * Question 5:
 *  a. Side Effect Free
 *  b. Mutates count
 *
 * Question 6:
 *  StringExercises
 *
 * Question 7:
 *  StringExercises
 */