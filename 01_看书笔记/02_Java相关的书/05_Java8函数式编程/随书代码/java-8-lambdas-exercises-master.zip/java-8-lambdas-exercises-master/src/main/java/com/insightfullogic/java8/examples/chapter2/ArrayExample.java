package com.insightfullogic.java8.examples.chapter2;

public class ArrayExample {

    // BEGIN ARRAY_INFERENCE
    final String[] array = { "hello", "world" };
    // END ARRAY_INFERENCE

}
