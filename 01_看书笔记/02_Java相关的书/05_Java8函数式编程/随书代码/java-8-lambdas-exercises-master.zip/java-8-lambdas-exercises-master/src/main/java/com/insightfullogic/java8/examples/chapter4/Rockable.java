package com.insightfullogic.java8.examples.chapter4;

public interface Rockable {

    public String rock();

}
