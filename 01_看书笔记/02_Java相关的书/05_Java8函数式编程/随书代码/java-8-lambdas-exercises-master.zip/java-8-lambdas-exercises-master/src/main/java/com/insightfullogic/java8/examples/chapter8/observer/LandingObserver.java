package com.insightfullogic.java8.examples.chapter8.observer;

// BEGIN LandingObserver
public interface LandingObserver {

    public void observeLanding(String name);

}
// END LandingObserver
