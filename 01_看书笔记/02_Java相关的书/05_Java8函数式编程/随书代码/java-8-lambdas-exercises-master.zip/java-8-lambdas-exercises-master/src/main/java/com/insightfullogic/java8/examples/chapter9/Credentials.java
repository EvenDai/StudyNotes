package com.insightfullogic.java8.examples.chapter9;

public class Credentials {
}
