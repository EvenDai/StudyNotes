package com.insightfullogic.java8.exercises.chapter4;

/**
 * Question 1:
 *  see PerformanceFixed
 *
 * Question 2:
 *  No - they are defined on java.lang.Object, and 'class always wins.'
 *
 * Question 3:
 *  See ArtistsFixed
 *
 */