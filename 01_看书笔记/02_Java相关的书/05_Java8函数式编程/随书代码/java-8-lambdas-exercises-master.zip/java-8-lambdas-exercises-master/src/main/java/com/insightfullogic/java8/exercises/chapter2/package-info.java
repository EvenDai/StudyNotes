package com.insightfullogic.java8.exercises.chapter2;

/**
 * Question 1:
 *  a. See Function.png
 *  b. Unary Operators, for example 'not'
 *  c. x -> x + 1;
 *
 * Question 2:
 *  a. N/A
 *
 * Question 3:
 *  a. Yes
 *  b. Yes
 *  c. No - the lambda expression could be inferred as IntPred or Predicate<Integer> so the overload is ambiguous.
 */