package com.insightfullogic.java8.examples.chapter5.mutable_custom;

public class Customer {
}
