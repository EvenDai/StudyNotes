package com.insightfullogic.java8.examples.chapter8.lambdabehave.reporting;

public interface ReportFormatter {

    public void format(Report report);

}
