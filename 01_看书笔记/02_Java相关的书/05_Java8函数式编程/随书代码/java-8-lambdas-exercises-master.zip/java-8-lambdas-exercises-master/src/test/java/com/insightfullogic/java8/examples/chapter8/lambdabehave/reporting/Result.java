package com.insightfullogic.java8.examples.chapter8.lambdabehave.reporting;

public enum Result {
    SUCCESS,
    ERROR,
    FAILURE
}
