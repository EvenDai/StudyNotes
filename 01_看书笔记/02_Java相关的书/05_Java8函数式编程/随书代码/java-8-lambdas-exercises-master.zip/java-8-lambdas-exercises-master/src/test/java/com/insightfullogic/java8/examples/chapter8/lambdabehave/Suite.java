package com.insightfullogic.java8.examples.chapter8.lambdabehave;

// BEGIN Suite
public interface Suite {

    public void specifySuite(Description description);

}
// END Suite
