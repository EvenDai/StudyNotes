package com.nealford.ft.polydispatch

interface Product {
  public int evaluate(int op1, int op2)
}
