

def isPalindrome(x: String) = x == x.reverse

def findPalidrome(s: Seq[String]) = s find isPalindrome



