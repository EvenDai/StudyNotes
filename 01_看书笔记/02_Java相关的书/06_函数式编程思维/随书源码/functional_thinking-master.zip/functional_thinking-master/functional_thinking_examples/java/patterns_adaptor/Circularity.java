package com.nealford.ft.adaptor;

public interface Circularity {
    public double getRadius();
}
