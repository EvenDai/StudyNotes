package org.flysnow.androidgradlebook.ex68.app;

/**
 * Created by 飞雪无情 on 16-1-22.
 */
public class HelloWorld {

}
