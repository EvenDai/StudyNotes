# GradleRecipesForAndroid
Source code for the book "Gradle Recipes for Android"

Everything uses plugin version 2.2.2.
