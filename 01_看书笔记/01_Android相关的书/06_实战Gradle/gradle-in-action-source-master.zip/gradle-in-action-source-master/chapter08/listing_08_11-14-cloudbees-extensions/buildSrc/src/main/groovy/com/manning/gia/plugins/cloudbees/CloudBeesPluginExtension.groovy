package com.manning.gia.plugins.cloudbees

class CloudBeesPluginExtension {
    String apiUrl
    String apiKey
    String secret
    String appId
}