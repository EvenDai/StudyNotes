package com.manning.gia.sanitycheck.input

interface TestSetReader {
    def parse(Reader reader)
}