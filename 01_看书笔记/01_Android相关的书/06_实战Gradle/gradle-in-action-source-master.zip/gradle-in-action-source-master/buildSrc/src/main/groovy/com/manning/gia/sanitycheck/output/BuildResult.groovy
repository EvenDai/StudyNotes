package com.manning.gia.sanitycheck.output

class BuildResult {
    String output
}