package com.manning.gia.sanitycheck.processing

class BuildVerificationException extends RuntimeException {
    BuildVerificationException(String message) {
        super(message)
    }
}