package com.apress.gerber.simplelayouts;

/**
* Created by Clifton
* Copyright 8/22/2014.
*/
class Person {
    public int image;
    public String name;
    public String location;
    public String website;
    public String descr;

    public Person(int image, String name, String location, String website, String descr) {
        this.image = image;
        this.name = name;
        this.location = location;
        this.website = website;
        this.descr = descr;
    }
}
