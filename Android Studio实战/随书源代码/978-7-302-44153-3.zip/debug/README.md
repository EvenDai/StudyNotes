# DEBUGME #

This is a debuggable example intended for Exploring Android Studio debugging features.

