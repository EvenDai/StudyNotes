The Currencies project located in the ch09.zip, ch10.zip, and ch11.zip are identical. You may import this project into Android Studio by navigating to File > Import Project from the main menu. Once imported, you may navigate this project's commit history by opening the Changes tool window and traversing the log. 

You may also clone this project by issuing the following command in git:

git clone https://csgerber@bitbucket.org/csgerber/currencies.git Currencies

