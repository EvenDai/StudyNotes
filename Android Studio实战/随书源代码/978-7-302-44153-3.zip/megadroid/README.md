# README #

### MegaDroid ###

This is the source code from Chapter 15, Wear.

### What does it cover? ###

* The basics of drawing an analog custom watch face
* Moving in/out of Ambient mode
* Lowbit mode
