package com.apress.gerber.helloworld;

/**
 * Created by ag on 4/19/2015.
 */
public class Minibox extends Sandbox {

}
